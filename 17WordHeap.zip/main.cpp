//HEAP and HEAP SORT ROUTINE
#include <fstream>
#include <iostream>
#include <string>
using namespace std;
// HEAP DECLARATIONS
template <class itemtype>
struct heaptype
{
    void reheapdown(int root, int bottom);
    void reheapup(int root, int bottom);
    itemtype* elements;
    int numelements;
};
template <class itemtype>
class heap
{
    int numitems; // Current num of items in the heap
    int maxitems; // max num of items the heap can hold
    heaptype<itemtype> heap_arr; // heap_arr is of the type struct heaptype
public:
    heap(int num); // num is used to determine the size of heap
    // it used to create an array for *elements in the
    //structure
    ~heap();
    // The following functions are used on the private array typ *elements
    void makeempty();
    int isempty();
    int isfull();
    void heap_print(ofstream&);// Output to file
    void heap_printc();
    void heap_insert(itemtype newitem);
    void heap_delete(itemtype& newitem);
    void sort();
};
// ==================================== HEAP
//FUNCTIONS===============================================
// GENERAL Compare
//functions====================================================== NOT USED
template <class itemtype>
int compare(itemtype s1, itemtype s2)
{
    if (s1 > s2) return 1;
    else if (s1 < s2) return -1;
    else return 0;
}
// CONSTRUCTOR============================================================
template <class itemtype>
heap<itemtype>::heap(int n)
{
    maxitems = n;
    numitems = 0;
    // Create an array of n elements
    heap_arr.elements = new itemtype[n];
}
//DESTRUCTOR================================================================
template <class itemtype>
heap<itemtype>::~heap()
{
    delete[] heap_arr.elements;
}
//MAKEEMPTY
//========================================================================
template <class itemtype>
void heap<itemtype>::makeempty()
{
    numitems = 0;
}
//IS EMPTY===================================================================
template <class itemtype>
int heap<itemtype>::isempty()
{
    return(numitems == 0);
}
//IS FULL====================================================================
template <class itemtype>
int heap<itemtype>::isfull()
{
    return (numitems == maxitems);
}
//PRINT==========================================================================
template <class itemtype>
void heap<itemtype>::heap_printc()
{
    int i;
    for (i = 0; i <= (numitems - 1); i++)
        cout << heap_arr.elements[i] << " ";
    cout << "\n";
}
//INSERT========================================================================
template <class itemtype>
void heap<itemtype>::heap_insert(itemtype newitem)
{
    numitems++;
    heap_arr.elements[numitems - 1] = newitem;
    heap_arr.reheapup(0, numitems - 1);// 0 and numitems-1 are the index values of
    //the array
}
//DELETE=========================================================================
template <class itemtype>
void heap<itemtype>::heap_delete(itemtype& newitem)
{
    newitem = heap_arr.elements[0];
    heap_arr.elements[0] = heap_arr.elements[numitems - 1];
    numitems--;
    heap_arr.reheapdown(0, numitems - 1);// 0 and numitems-1 are the index values of
   //the array
}
//REHEAPDOWN=====================================================================
/* THE HEAP IS STORED FROM HIGHEST in the root to LOWEST VALUE in the last
location
The reheapdown is normally called from DELETE function. The maximum item which is
stored
in the first index (i.e root) is deleted and the last item in the heap replaces
the one deleted
in the DELETE function. Then we have to reheapdown from root to maintan the heap
*/
template <class itemtype>
void heaptype<itemtype>::reheapdown(int root, int bottom) // root and bottom are
//the index values of the array
{
    int maxchild;
    int rightchild;
    int leftchild;
    leftchild = root * 2 + 1;
    rightchild = root * 2 + 2;
    if (leftchild <= bottom)
    {
        if (leftchild == bottom) // i.e no right child
            maxchild = leftchild;
        else
        {
            // if ( compare(elements[leftchild], elements[rightchild]) == 1) //
            //<=
            if (elements[leftchild] > elements[rightchild])
            {
                maxchild = leftchild;
            }
            else
            {
                maxchild = rightchild;
            }
        }
        // if (compare( elements[root], elements[maxchild]) == -1) // < Store
       //largest value in root
        if (elements[root] < elements[maxchild])
        {
            // swap(elements[root],elements[maxchild]);
            itemtype t;
            t = elements[root];
            elements[root] = elements[maxchild];
            elements[maxchild] = t;
            reheapdown(maxchild, bottom); // Calling recursively
        }
    }
}
//REHEAP UP======================================================================
/* HEAP values are maintained from highest in ROOT to lowest.
The reheapup is called from INSERT function. The new item in the insert is
added as the last item. Hence we have to reheapup until it
becomes a heap again
*/
template <class itemtype>
void heaptype<itemtype>::reheapup(int root, int bottom) // root and bottom are
//the index values of the array
{
    int parent;
    if (bottom > root)
    {
        parent = (bottom - 1) / 2;
        // if ( compare( elements[parent], elements[bottom]) == -1) // to Store
        //the highest
         // value in
        //root
        if (elements[parent] < elements[bottom])
        {
            //swap(elements[parent],elements[bottom]);
            itemtype t;
            t = elements[parent];
            elements[parent] = elements[bottom];
            elements[bottom] = t;
            reheapup(root, parent); // Call Recursively
        }
    }
}
// SORT routine of a heap array
//================================================================================
template <class itemtype>
void heap<itemtype>::sort()
{
    int index;
    for (index = numitems - 1; index >= 1; index--)
    {
        // Place the largest item from the root to the last location and then
        // REHEAP ONLY using one location LESS. This means the last location
        //now has the
        // largest value.
        //swap(heap_arr.elements[0], heap_arr.elements[index]);
        itemtype t;
        t = heap_arr.elements[0];
        heap_arr.elements[0] = heap_arr.elements[index];
        heap_arr.elements[index] = t;
        heap_arr.reheapdown(0, index - 1);
    }
}
// HEAP FUNCTION ENDS ++++++++++++++++++++++++++++++++
int main()
{
    int total = 17;
    string num;
    // Create a heap of the size total;
    heap<string> h(total);
    for (int i = 0; i <= 16; i++)
    {
        cout << " Enter a word : ";
        cin >> num;
        h.heap_insert(num);//heap_insert inserts value as the last element in
        //the array and calls reheapup funtion recursively
    }
    cout << "\n\n After heap \n\n";
    h.heap_printc();

    h.sort();
    cout << " \n\nAfter sort \n\n";
    h.heap_printc();
    return 1;
}