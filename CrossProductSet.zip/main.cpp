#include <iostream>
using namespace std;
int Cross(int m, int n, int set[][2])
{
int a = 0;
for (int i = 1; i <= m; i++)
{
  for (int j = 1; j <= n; j++)
  {
 set[a][0] = i, set[a][1] = j;
 a++;
  }
}
return a;
}

void printSet(int NumElements)
{
int j;
cout << "{ ";
for (j = 0; j < NumElements - 1; j++)
  cout << j+1 << ", ";
cout << j+1 << " }" << endl;
}

void printProductSet(int set[][2], int NumRows)
{
cout << "{ ";
for (int i = 0; i < NumRows - 1; i++)
  cout << "(" << set[i][0] << ", " << set[i][1] << "), ";
cout << "(" << set[NumRows - 1][0] << ", " << set[NumRows - 1][1] << ") }" << endl;
}

int main()
{
int set[100][2];
int NumRows, NumElements1, NumElements2;
do
{
  cout << "Input two integer numbers that are positive to represent m and n (0 < m, n < 11): ";
  cin >> NumElements1 >> NumElements2;
} while (NumElements1 < 1 || NumElements1 > 10 || NumElements2 < 1 || NumElements2 > 10);
cout << "A = ";
printSet(NumElements1);
cout << "B = ";
printSet(NumElements2);
NumRows = Cross(NumElements1, NumElements2, set);
cout << "A X B = ";
printProductSet(set, NumRows);
return 0;
}
