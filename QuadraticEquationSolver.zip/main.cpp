#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int main() {
  double a,b,c;
  cout << "Quadratic Equation Solver: ax^2 + bx + c = 0" << endl;
  cout << "Please enter your A value" << endl;
  cin >> a;
  cout << "Please enter your B value" << endl;
  cin >> b;
  cout << "Please enter your C value" << endl;
  cin >> c;
  if (a == 0 && b==0 && c == 0) {
  cout << "All three values are 0" << endl;
  return 0;
  }
  else if (a == 0) {
  cout << "A is 0, so there is no real solution" << endl;
  return 0;
  }
  else if (a != 0 ) {
  double discriminant = (b*b - 4 * a * c);
  if(discriminant < 0) {
  cout << "The discriminant is less than 0, so there is no real solution" << endl;
  return 0;
  }
  else if(discriminant == 0)
  cout << "The discriminant is 0" << endl;
  else if(discriminant > 0)
  cout << "The discriminant is more than 0" << endl;
  }
  double positiveanswer = (-b + sqrt(b * b - 4 * a * c)) / (2 *a);
  double negativeanswer = (-b - sqrt(b * b - 4 * a * c)) / (2 *a);
  cout << setprecision(5) << "There are 2 real solutions: " << positiveanswer << " and "  << negativeanswer << endl;
  return 1;
}