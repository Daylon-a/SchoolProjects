#include <iostream>
#include "Sort.h"

using namespace std;

int arr[8];

int main() 
{ 
    for (int i = 0; i < 8; i++) {
      int randomnumber = (rand() % 100) + 1;
      arr[i] = randomnumber;
    } //Random numbers
    int arrSize = sizeof(arr)/sizeof(arr[0]);
    Sort p1(arr,arrSize);
    cout << "Unsorted array: \n";
    p1.print(arr, arrSize);
    p1.insertionSort(arr, arrSize); //any sort method can go here 
    cout << "Sorted array using insertion sort: \n"; 
    p1.print(arr, arrSize);
    return 0; 
}

//Also works for selection sort, merge sort, and quick sort
