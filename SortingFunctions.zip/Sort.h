//--------------------------------------------------------------------
//
//  Homework                                            Sort.h
//
//  Class declaration for the sort algorithms
//
//--------------------------------------------------------------------

#ifndef SORT_H
#define SORT_H


using namespace std;

class Sort
{
  public:
    // Constructors
    Sort(int arr[], int num); // Default constructor
    // Destructor
    ~Sort();

    // Vector manipulation operations
    void selectionSort(int arr[], int num); // implement the selection sort algorithm
    void insertionSort(int arr[], int num); // implement the selection sort algorithm
    void mergeSort(int arr[],int l,int r);   // call mergeSort with parameters
    void merge(int arr[], int l, int m, int r); // merge A and B to C in ascending order
    void quickSort(int arr[], int low, int high);   // call quickSort with parameters
    int partition(int arr[], int low, int high);  // Quick sort algorithm: partition the list using a pivot and return the position of the pivot after partitioning
    void print(int arr[], int num);       // print all items in the dataItems
    int  getSize() const { return size;}           // Return the number of items in the vector
    char* getData() const {return dataItems;}

  private:
    // Data members
    int size;        // Actual number of data item in the vector
    char *dataItems;  // Array containing the vector data item  
};

#endif

