#include <iostream>
#include <fstream>
#include <string.h>
#include <algorithm>
using namespace std;


template <class itemtype>
struct nodetype
{
itemtype info;
nodetype *next;
};
template <class itemtype>
class quetype
{
public:
quetype();
~quetype();
void makeempty();
void enqueue(itemtype);
void dequeue(itemtype &);
int isempty();
int isfull();
private:
nodetype<itemtype> *qfront, *qrear;
};
// CONSTRUCTOR
template <class itemtype>
quetype<itemtype>::quetype()
{
qfront = NULL;
qrear = NULL;
}
//DESTRUCTOR
template <class itemtype>
quetype<itemtype>::~quetype()
{
makeempty();
};
// MAKEEMPTY
template <class itemtype>
void quetype<itemtype>::makeempty()
{
nodetype<itemtype> *tempptr;
while (qfront != NULL)
{
tempptr = qfront;
qfront = qfront->next;
delete tempptr;
}
qrear=NULL;
}
// ISEMPTY
template <class itemtype>
int quetype<itemtype>::isempty()
{
return(qfront == NULL);
}
//ISFULL
template <class itemtype>
int quetype<itemtype>::isfull()
{
nodetype<itemtype> *ptr;
ptr=new nodetype<itemtype>;
if(ptr==NULL)
return true;
else
{
delete ptr;
return (0);
}
}
// ENTER QUEUE
template <class itemtype>
void quetype<itemtype>::enqueue(itemtype item)
{
nodetype<itemtype> *newnode;
newnode = new nodetype<itemtype>;
newnode->info = item;
newnode->next=NULL;
if(qrear==NULL)
qfront = newnode;
else
 qrear->next = newnode;
qrear = newnode;
}
// DELETE QUEUE
template <class itemtype>
void quetype<itemtype>::dequeue(itemtype &item)
{
nodetype<itemtype> *tempptr;
tempptr = qfront;
item =qfront->info;
qfront = qfront->next;
if (qfront==NULL)
qrear=NULL;
delete tempptr;
}
template <class itemtype>
struct st
{ itemtype a;
st *next;
};

template <class itemtype>
class s
{
public:
s();
~s();
void push(itemtype c);
itemtype pop();
bool isempty();
int isfull();
void print();
private:
st<itemtype> *top;
};
template <class itemtype>
s<itemtype>::s()
{ top = NULL; }
template <class itemtype>
s<itemtype>::~s()
{ }
// Pushes ONE item into the stack using TOP
template <class itemtype>
void s<itemtype>::push(itemtype c)
{
st<itemtype> *t;
t = new st<itemtype>; // create a node
t->a= c; // Assign the node
t ->next = top; // Add to the link list
if (top == NULL)
{ top = t; }
else
{ top = t; }
}
// POP deletes one item using TOP and returns the value delted
template <class itemtype>
itemtype s<itemtype>::pop()
{
itemtype x;
st<itemtype> *t;
x=top->a;
t = top;
top = top ->next;
t->next = NULL;
delete t;

return x;
}
// Check whether the stack is empty
template <class itemtype>
bool s<itemtype>::isempty()
{
if (top == NULL)
return true;
else
return false;
}
//ISFULL
template <class itemtype>
int s<itemtype>::isfull()
{
st<itemtype> *ptr;
ptr=new st<itemtype>;
if(ptr==NULL)
return true;
else
{ delete ptr;
return (0);
}
}
template <class itemtype>
void s<itemtype>::print()
{
st<itemtype> *t;
t = top;
while (t != NULL)
{
cout << t->a << endl;
t = t->next;
}
}

int main(){
  ifstream infile;
  ofstream outfile; //out file
  infile.open("indata.txt");
  outfile.open("out.txt");
 string character;
 s<char>stack;
 quetype<char>queue;
 char StackCharacter;
 char queChar;
 char queRear=character[0];
 bool palindrome=true;
while(infile.peek()!=EOF)//loop to read in infile
{
  getline(infile,character);
  cout<<endl;
  outfile<<character<<"\t"<<endl;
  transform(character.begin(), character.end(), character.begin(), ::tolower);

  int l=character.length();
  for(int i=0;i<l;i++)
  {
  if(character[i]!=' '){    
  StackCharacter=character[i];
  queChar=character[i];
  queue.enqueue(queChar);
  stack.push(StackCharacter);
  }
  }
while(!stack.isempty())
{
  char f;
  char compare = stack.pop();
  queue.dequeue(f);
  if(f!=compare)//to see if its a palindrome or not 
  {
    palindrome = false;
  }
}
if(palindrome == true)
{
  outfile<<" is palindrome"<<endl;
}
else{ 
outfile<< " not a palindrome"<<endl;
}
palindrome=true;
}
cout << "Palindrome information has been successfully exported to outfile! \n";
}
