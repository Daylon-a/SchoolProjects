
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <stdio.h>

//define
#define LENGTH 75
#define NUM_THREADS 4

int arr[LENGTH];
int side = 0;

//function prototypes
void merge(int low, int mid, int   high);
void merge_sort(int low, int high);
void *thread_merge_sort(void *arg);
void shuffle(int *array, int n);

void merge(int low, int mid, int high) //DONE
{
  int i,j,k;
  int *left = malloc((mid - low + 1) * sizeof(int)); //malloc(+sizeof()) is equivalent to C++ new
  int *right = malloc((high - mid) * sizeof(int));

  int n1 = mid - low + 1; //left size
  int n2 = high - mid;    //right size
  
  // storing values in left
  for (i = 0; i < n1; i++)
    left[i] = arr[i + low];

  // storing values in right
  for (i = 0; i < n2; i++)
    right[i] = arr[i + mid + 1];
  
  k = low;
  i = j = 0;
  
  // merge in ascending order
  while (i < n1 && j < n2) {
      if (left[i] <= right[j])
          arr[k++] = left[i++];
      else
          arr[k++] = right[j++];
  }
  
    //insert remaining from left and right
    while (i < n1) {
        arr[k++] = left[i++];
    }
    while (j < n2) {
        arr[k++] = right[j++]; 
    }
}
//evaluate mid & merge
void merge_sort(int low, int high) //DONE
{
  int mid = low + (high - low) / 2;
  if (low < high) 
  {
      merge_sort(low, mid); //call left
      merge_sort(mid + 1, high); //call right
      merge(low, mid, high); //merge
  }
}
void* thread_merge_sort(void *arg) //**CHECK Function
{
  // which part out of 4 parts
    int thread_part = (long)arg;
    // calculating low and high
    int low = thread_part * (LENGTH);
    int high = (thread_part + 1) * (LENGTH) - 1;
    //merge
    merge_sort(low,high);
  return 0;
}
void shuffle(int *array, int n)
{
    srand((unsigned)time(NULL));
    for (int i = 0; i < n - 1; i++) {
        size_t j = i + rand() / (RAND_MAX / (n - i) + 1);
        int t = array[j];
        array[j] = array[i];
        array[i] = t;
    }
}

int main()
{
    // generating random 5 digit ID 
    srand (time(NULL));
    for (int i = 0; i < LENGTH; i++)
        arr[i] = rand() %  99999 + 10000;
  
    // t1 and t2 for calculating time
    clock_t start, end;
    
    // create threads

    printf("\n\nIncoming Patient IDs:");
    for (int i = 0; i < LENGTH; i++){
      if (i%5==0)
        printf("\n");
      printf(" %d", arr[i]);
    }
    
  //merge threads. ****************

    start = clock();
    merge_sort(0, LENGTH -1);
    end = clock();
    //print
    printf("\n\nSorted Patient IDs:");
    for (int i = 0; i < LENGTH; i++){
      if (i%5==0)
        printf("\n");
      printf(" %d", arr[i]);
    }
  
  double cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
  printf("\n\n   seconds to execute:  %f", cpu_time_used);


  printf("\n\n\n********************");
  shuffle(arr, LENGTH);

  //*********************************
  printf("\n\nIncoming Patient IDs:");
    for (int i = 0; i < LENGTH; i++){
      if (i%5==0)
        printf("\n");
      printf(" %d", arr[i]);
    }

    
    pthread_t threads[NUM_THREADS];
  
    // creating 4 threads
    for (int i = 0; i < NUM_THREADS; i++)
        pthread_create(&threads[i], NULL, thread_merge_sort,
                                        (void*)NULL);
  
    // joining all 4 threads
    for (int i = 0; i < 4; i++)
        pthread_join(threads[i], NULL);
  
    // merging the final 4 parts ***should we time threads
    start = clock();
    merge(0, (LENGTH / 2 - 1) / 2, LENGTH / 2 - 1);
    merge(LENGTH / 2, LENGTH/2 + (LENGTH-1-LENGTH/2)/2, LENGTH - 1);
    merge(0, (LENGTH - 1)/2, LENGTH - 1);
    end = clock();
    printf("\n\nThread Sorted Patient IDs:");
    for (int i = 0; i < LENGTH; i++){
      if (i%5==0)
        printf("\n");
      printf(" %d", arr[i]);
    }
    
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("\n\n    seconds to execute:  %f", cpu_time_used);

    printf("\n");
    printf("\n");
    //printf("Time Clocked: %d", t2);
    
    return 0;
}                                               

