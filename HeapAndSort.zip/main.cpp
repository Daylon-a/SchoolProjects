//HEAP and HEAP SORT ROUTINE
#include <fstream>
#include <iostream>
#include <string>
using namespace std;
// HEAP DECLARATIONS
template <class itemtype>
struct heaptype
{
    void reheapdown(int root, int bottom);
    void reheapup(int root, int bottom);
    itemtype* elements;
    int numelements;
};
template <class itemtype>
class heap
{
    int numitems; // Current num of items in the heap
    int maxitems; // max num of items the heap can hold
    heaptype<itemtype> heap_arr; // heap_arr is of the type struct heaptype
public:
    heap(int num); // num is used to determine the size of heap
    // it used to create an array for *elements in the
    //structure
    ~heap();
    // The following functions are used on the private array typ *elements
    void makeempty();
    int isempty();
    int isfull();
    void heap_print(ofstream& output);// Output to file
    void heap_printc();
    void heap_insert(itemtype newitem);
    void heap_delete(itemtype& newitem);
    void sort();
};
// ==================================== HEAP
//FUNCTIONS===============================================
// GENERAL Compare
//functions====================================================== NOT USED
template <class itemtype>
int compare(itemtype s1, itemtype s2)
{
    if (s1 > s2) return 1;
    else if (s1 < s2) return -1;
    else return 0;
}
// CONSTRUCTOR============================================================
template <class itemtype>
heap<itemtype>::heap(int n)
{
    maxitems = n;
    numitems = 0;
    // Create an array of n elements
    heap_arr.elements = new itemtype[n];
}
//DESTRUCTOR================================================================
template <class itemtype>
heap<itemtype>::~heap()
{
    delete[] heap_arr.elements;
}
//MAKEEMPTY
//========================================================================
template <class itemtype>
void heap<itemtype>::makeempty()
{
    numitems = 0;
}
//IS EMPTY===================================================================
template <class itemtype>
int heap<itemtype>::isempty()
{
    return(numitems == 0);
}
//IS FULL====================================================================
template <class itemtype>
int heap<itemtype>::isfull()
{
    return (numitems == maxitems);
}
//PRINT==========================================================================
template <class itemtype>
void heap<itemtype>::heap_print(ofstream& output)
{
    int i;
    for (i = 0; i <= (numitems - 1); i++)
        output << heap_arr.elements[i] << " "
        << "\n";
}

template <class itemtype>
void heap<itemtype>::heap_printc()
{
    int i;
    for (i = 0; i <= (numitems - 1); i++)
        cout << heap_arr.elements[i] << " ";
    cout << "\n";
}
//INSERT========================================================================
template <class itemtype>
void heap<itemtype>::heap_insert(itemtype newitem)
{
    numitems++;
    heap_arr.elements[numitems - 1] = newitem;
    heap_arr.reheapup(0, numitems - 1);// 0 and numitems-1 are the index values of
    //the array
}
//DELETE=========================================================================
template <class itemtype>
void heap<itemtype>::heap_delete(itemtype& newitem)
{
    newitem = heap_arr.elements[0];
    heap_arr.elements[0] = heap_arr.elements[numitems - 1];
    numitems--;
    heap_arr.reheapdown(0, numitems - 1);// 0 and numitems-1 are the index values of
   //the array
}
//REHEAPDOWN=====================================================================
/* THE HEAP IS STORED FROM HIGHEST in the root to LOWEST VALUE in the last
location
The reheapdown is normally called from DELETE function. The maximum item which is
stored
in the first index (i.e root) is deleted and the last item in the heap replaces
the one deleted
in the DELETE function. Then we have to reheapdown from root to maintan the heap
*/
template <class itemtype>
void heaptype<itemtype>::reheapdown(int root, int bottom) // root and bottom are
//the index values of the array
{
    int maxchild;
    int rightchild;
    int leftchild;
    leftchild = root * 2 + 1;
    rightchild = root * 2 + 2;
    if (leftchild <= bottom)
    {
        if (leftchild == bottom) // i.e no right child
            maxchild = leftchild;
        else
        {
            // if ( compare(elements[leftchild], elements[rightchild]) == 1) //
            //<=
            if (elements[leftchild] > elements[rightchild])
            {
                maxchild = leftchild;
            }
            else
            {
                maxchild = rightchild;
            }
        }
        // if (compare( elements[root], elements[maxchild]) == -1) // < Store
       //largest value in root
        if (elements[root] < elements[maxchild])
        {
            // swap(elements[root],elements[maxchild]);
            itemtype t;
            t = elements[root];
            elements[root] = elements[maxchild];
            elements[maxchild] = t;
            reheapdown(maxchild, bottom); // Calling recursively
        }
    }
}
//REHEAP UP======================================================================
/* HEAP values are maintained from highest in ROOT to lowest.
The reheapup is called from INSERT function. The new item in the insert is
added as the last item. Hence we have to reheapup until it
becomes a heap again
*/
template <class itemtype>
void heaptype<itemtype>::reheapup(int root, int bottom) // root and bottom are
//the index values of the array
{
    int parent;
    if (bottom > root)
    {
        parent = (bottom - 1) / 2;
        // if ( compare( elements[parent], elements[bottom]) == -1) // to Store
        //the highest
         // value in
        //root
        if (elements[parent] < elements[bottom])
        {
            //swap(elements[parent],elements[bottom]);
            itemtype t;
            t = elements[parent];
            elements[parent] = elements[bottom];
            elements[bottom] = t;
            reheapup(root, parent); // Call Recursively
        }
    }
}
// SORT routine of a heap array
//================================================================================
template <class itemtype>
void heap<itemtype>::sort()
{
    int index;
    for (index = numitems - 1; index >= 1; index--)
    {
        // Place the largest item from the root to the last location and then
        // REHEAP ONLY using one location LESS. This means the last location
        //now has the
        // largest value.
        //swap(heap_arr.elements[0], heap_arr.elements[index]);
        itemtype t;
        t = heap_arr.elements[0];
        heap_arr.elements[0] = heap_arr.elements[index];
        heap_arr.elements[index] = t;
        heap_arr.reheapdown(0, index - 1);
    }
}
// HEAP FUNCTION ENDS ++++++++++++++++++++++++++++++++
template <class itemtype>
struct nodetype
{
    itemtype word;
    int freq;
    nodetype* next;
};
// Unsorted Linked list Class node
template <class itemtype>
class unsortedtype
{
public:
    //constructor. Sets the length to zero and listdat to null
    unsortedtype();
    int isfull();
    // Returns the number of items in ONE linked list of an object in the array
    int lengthis();
    // One item is inserted in the beginning. Insertitem is called after a word is read and if it is not already existing.
    void insertitem(itemtype item);
    //Sets the value of currentpos to NULL
    void resetlist();
    // Gets the item pointed to by currentpos
    void getnextitem(itemtype item);
    // If the index location of a given word is NOT empty modify searches for a given word. //If found,
    void modify(itemtype item, int& found);
    // Print outputs all items in a linked list to an output file
    void print(ofstream&);
    //PRINT outputs all items in a linked list to MONITOR
    void printc();
    //Go through the linked list and return a value based on the counter
    string traverselist(int counter);
private:
    nodetype<itemtype>* listdata;
    nodetype<itemtype>* currentpos;
    int length;
};
// constuctor
template <class itemtype>
unsortedtype<itemtype>::unsortedtype() {
    listdata = NULL;
    currentpos = NULL;
    length = 0;
}
// Returns if the linked list is full (17)
template <class itemtype>
int unsortedtype<itemtype>::isfull() {
    return (length == 17);
}
// Returns the length
template <class itemtype>
int unsortedtype<itemtype>::lengthis() {
    return length;
}
// Inserts new items into the linked list
template <class itemtype>
void unsortedtype<itemtype>::insertitem(itemtype item) {
    nodetype<itemtype>* temp;
    temp = new nodetype<itemtype>;
    temp->word = item;
    if (listdata == NULL) {
        listdata = temp;
        currentpos = temp;
        length++;
    }
    else {
        listdata = temp;
        temp->next = currentpos;
        currentpos = temp;
        length++;
    }
}
// Resets the list to normal values
template <class itemtype>
void unsortedtype<itemtype>::resetlist() {
    listdata = NULL;
    currentpos = NULL;
}
// Method to get the next item of a desired word in the linked list
template <class itemtype>
void unsortedtype<itemtype>::getnextitem(itemtype item) {
    nodetype<itemtype>* temp;
    temp = listdata;
    if (temp->word == item) {
        temp = temp->next;
        cout << temp->word << endl;
    }
    else if (temp->word == item && temp->word = NULL) {
        cout << "This is the last word in the linked list!" << endl;
    }
    else {
        while (temp->word != item) {
            temp = temp->next;
        }
        temp = temp->next;
        cout << temp->word << endl;
    }
}
// Unused method
template <class itemtype>
void unsortedtype<itemtype>::modify(itemtype item, int& found) {
    string word;
}
//prints the list to the output file (backwards! :) )
template <class itemtype>
void unsortedtype<itemtype>::print(ofstream& output) {
    nodetype<itemtype>* temp;
    temp = listdata;
    while (temp != NULL) {
        output << temp->word << endl;
        temp = temp->next;
    }
}
//prints the linked list to the moniter
template <class itemtype>
void unsortedtype<itemtype>::printc() {
    nodetype<itemtype>* temp;
    temp = listdata;
    while (temp != NULL) {
        cout << temp->word << " ";
        temp = temp->next;
    }
}
// Traverses the list, and returns the value based on the counter it's given
template <class itemtype>
string unsortedtype<itemtype>::traverselist(int counter) {
    nodetype<itemtype>* temp;
    temp = listdata;
    for (int i = 0; i <= counter - 1; i++) {
        temp = temp->next;
    }
    return temp->word;
}

int main() {
    string word;
    string currentitem;
    int counter;
    unsortedtype<string> x;
    /* ifstream input;
    input.open("input.txt");
    ofstream unsort;
    unsort.open("unsort.txt");
    ofstream usortout;
    usortout.open("usortout.txt");
    ofstream unsortout;
    unsortout.open("unsortout.txt");
     */
     /* while (getline(input, word)) {
        (x.insertitem(word));
    }
    counter = x.lengthis();
    heap<string> h(counter);
    for (int i = 0; i <= counter - 1; i++) {
        currentitem = x.traverselist(i);
        h.heap_insert(currentitem);
    }
    cout << "DATA READ FROM THE INPUT FILE" << endl;
    cout << "-------------------------------------" << endl;
    x.print(usortout);
    cout << endl << "=============================================================================" << endl;
    cout << "DATA AFTER HEAP:" << endl;
    cout << "-------------------------------------" << endl;
    h.heap_print(unsortout);
    cout << endl << "=============================================================================" << endl;
    cout << "DATA AFTER SORT:" << endl;
    cout << "-------------------------------------" << endl;
    h.sort();
    h.heap_print(unsort); */
    x.getnextitem(16);
    x.printc();
    return 1;
}