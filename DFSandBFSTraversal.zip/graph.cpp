#include <iostream>
#include "graph.h"
#include <list>

using namespace std;

graph::graph()
{
}

void graph::addVertex(const Node node)
{
	vertices.push_back(node);
}

void graph::addEdge(const char from, const char to)
{
	vertices[from-'a'].edges.push_back(to);
	vertices[to-'a'].edges.push_back(from);
}

void graph::print()
{
	for(int i=0; i<vertices.size(); i++)
	{
		cout << vertices[i].name << ": ";
		for (int j=0; j<vertices[i].edges.size(); j++)
			cout << vertices[i].edges[j] << ", ";
		cout << endl;
	}
}

void graph::DFS() {
cout << "DFS: ";
for (int i = 0; i < vertices.size(); i++){
  if (vertices[i].visited == 0) {
dfs(vertices[i]);
  }
}
  cout << endl;
}

void graph::dfs(Node& node) {
node.visited = 1;
cout << node.name << " ";
for (int i = 0; i < node.edges.size(); i++){
  if (vertices[node.edges[i] - 'a'].visited == 0) {
dfs(vertices[node.edges[i] - 'a']);
}
}
}

void graph::reset()
{
	for(int i=0; i<vertices.size(); i++)
		vertices[i].visited = 0;
	count = 0;
}

void graph::BFS()
{
  cout << "BFS: ";
for (int i = 0; i < vertices.size(); i++)
{
if (vertices[i].visited == 0)
bfs(vertices[i]);
}
cout << endl;
}

void graph::bfs(Node& node)
{
  list<int> queue;
node.visited = 1;
queue.push_back(node.name - 'a');

//list<int>::iterator i

while (!queue.empty())
{
int s = queue.front();
cout << (char)(s + 'a') << " ";
queue.pop_front(); node = vertices[s];
for (int i = 0; i < node.edges.size(); i++)
{
if (vertices[node.edges[i] - 'a'].visited == 0)
{
vertices[node.edges[i] - 'a'].visited = 1;
queue.push_back(node.edges[i] - 'a');
}
}
}
}

