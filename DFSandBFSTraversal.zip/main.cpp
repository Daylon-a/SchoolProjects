#include <iostream>
#include "graph.h"
#include <list>

using namespace std;

int main()
{
	graph myGraph;
	int num = 8;
	for(int i=0; i<num; i++)
	{
		Node node('a'+i);
		myGraph.addVertex(node);
	}
    myGraph.addEdge('a', 'b');
    myGraph.addEdge('a', 'e');
    myGraph.addEdge('a', 'f');
    myGraph.addEdge('b', 'f');
    myGraph.addEdge('b', 'g');
    myGraph.addEdge('c', 'd');
    myGraph.addEdge('c', 'h');
    myGraph.addEdge('d', 'g');
    myGraph.addEdge('e', 'f');
    myGraph.addEdge('g', 'h');
	myGraph.print();
	myGraph.DFS();
	myGraph.reset();
  myGraph.BFS();
	return 0;
}